//
//  Users.m
//  MyBridgeApp
//
//  Created by Sagar Sinha on 6/9/16.
//  Copyright © 2016 Parse. All rights reserved.
//

#import "Users.h"

@implementation Users

// Insert code here to add functionality to your managed object subclass

@end
