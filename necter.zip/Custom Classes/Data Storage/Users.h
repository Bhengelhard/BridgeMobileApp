//
//  Users.h
//  MyBridgeApp
//
//  Created by Sagar Sinha on 6/9/16.
//  Copyright © 2016 Parse. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Users : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Users+CoreDataProperties.h"
