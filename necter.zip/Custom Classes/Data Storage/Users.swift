//
//  Users.swift
//  MyBridgeApp
//
//  Created by Sagar Sinha on 6/9/16.
//  Copyright © 2016 BHE Ventures LLC. All rights reserved.
//

import Foundation
import CoreData


class Users: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
